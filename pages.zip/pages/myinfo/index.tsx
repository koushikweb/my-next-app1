import React from 'react';

const MyInfo: React.FC = () => {
  return (
    <div>
      <h1> A new info</h1>
      <p>Show user info.</p>
    </div>
  );
};

export default MyInfo;