import React from 'react';

const Cart: React.FC = () => {
  return (
    <div>
      <h1> Cart</h1>
      <p>Your shopping cart content</p>
    </div>
  );
};

export default Cart;